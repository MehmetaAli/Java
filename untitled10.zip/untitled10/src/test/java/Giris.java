import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

public class Giris {
    WebDriver driver ;

    @BeforeAll

    public void webSitesAcme(){


   WebDriver driver=new ChromeDriver();

    driver.manage().window().maximize();

    driver.get("https://www.gittigidiyor.com/");

    driver.get("https://www.gittigidiyor.com/uye-girisi?s=1");
    driver.findElement(By.name("kullanici")).sendKeys("E-posta");

    driver.findElement(By.name("sifre")).sendKeys("Şifre");

    driver.findElement(By.id("gg-login-enter")).click();
    driver.get("https://www.gittigidiyor.com/");


}}
