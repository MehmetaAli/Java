import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Giris2 {
    @Test
    public void webSitesAcme(){

        WebDriver driver=new ChromeDriver();

        driver.manage().window().maximize();

        driver.get("https://www.gittigidiyor.com/");
        driver.get("https://www.gittigidiyor.com/uye-girisi?s=1");

        driver.findElement(By.name("username")).sendKeys("enter username");
        //pay attention here By.name or By.id, see  the page source properly
        driver.findElement(By.name("password")).sendKeys("enter password");

        driver.findElement(By.xpath("//button[@value='login']")).click();

        driver.findElement(By.name("participant")).sendKeys("BLRFC1");
        driver.findElement(By.xpath("//button[@type='submit']")).click();

    }





}
