import junit.framework.AssertionFailedError;
import org.junit.jupiter.api.Order;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;
import org.junit.jupiter.api.Assertions;

public class Arama extends  Giris{

    HomePage homePage;
    ProductPage productPage;
    ProductDetailPage productDetailPage;
    CartPage cartPage;

    @Test
    @Order(1)
    public void bilgisayar(){
        homePage=new HomePage(driver);
        productPage=new ProductPage(driver);
        homePage.searchBox().search("Bilgisayar");
        Assertions.assertTrue(productPage.isOnProductPage,"Not on pruducts page!");
    }
    public void Sayfa(){

    }
    @Test
    @Order(2)
    public void Secme(){
        productDetailPage=new ProductDetailPage(driver);
        productPage.selectProduct(1);
        Assertions.assertTrue( productDetailPage.isOnProductDetailPage(),"Not on oroductdetail page'");

    }
    @Test
    @Order(3)
    public void Sepete(){
        productDetailPage.addToCart();
        Assertions.assertTrue(homePage.isProductCountUp(),"Product count did not increase");

    }
    @Test
    @Order(4)
    public void Sepetegitme(){
        cartPage=new CartPage(driver);
        homePage.goToCart();
        Assertions.assertTrue(cartPage.checkIfPruductAdded(),"Product was bot added not cart");

    }
}
