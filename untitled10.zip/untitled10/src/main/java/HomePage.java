import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Stack;

public class HomePage extends Baslangıc {

    SearchBox searchBox;;
    By cartCountLocator = By.className("nav-cart-count");
    By cartContainerLocator = By.className("nav-cart-count-container");
    By acceptCookiesLocator = By.className("img-cont");


    public HomePage(WebDriver driver) {
        super(driver);
        searchBox=new SearchBox(driver);
    }

    public SearchBox searchBox() {
        return   this.searchBox();
    }

    public boolean isProductCountUp() {
        return getCartCount() > 0 ;
    }

    public void goToCart() {
    }
    private int getCartCount(){
        String count = find(cartCountLocator).getText();
        return Integer.parseInt(count);
    }
    public void acceptCookies(){
        if (isDisplayed(acceptCookiesLocator)){
            click(acceptCookiesLocator);
        }
}}
