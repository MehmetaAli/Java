import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ProductPage extends Baslangıc {
    public boolean isOnProductPage;
    By shippingOptionLocator = By.id("gt-category-browse-navigation-title");
    By productNameLocator = new By.ByCssSelector("img-cont");



    public ProductPage(WebDriver driver) {
        super(driver);
    }
    public boolean isOnProductPage() {
        return isDisplayed(shippingOptionLocator);
    }

    public void selectProduct(int i) {
        getAllProducts().get(i).click();

    }
    private List<WebElement> getAllProducts(){
        return findAll(productNameLocator);
    }
}
