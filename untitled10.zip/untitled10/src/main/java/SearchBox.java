import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchBox extends Baslangıc {

    By searchBoxLocator=By.id("search_word");
    By submitButtonLocator=By.id("header-search-find-link");
    public SearchBox(WebDriver driver) {
        super(driver);
    }

    public void search(String bilgisayar) {
        type(searchBoxLocator , bilgisayar);
        click(submitButtonLocator);

    }
}
